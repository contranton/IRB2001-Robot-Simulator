Programado por Javier Contreras Kotova para IRB2001 2017-1 en la Pontificia Universidad Católica de Chile

HECHO CON PYTHON 3.6. ALGUNAS COSAS PODRIAN NO FUNCIONAR EN VERSIONES ANTERIORES (operador @ en numpy)

Indicaciones:
	- Usa las flechas para mover el robot, y S para frenarlo por completo

	- Activa el modo de seguimiento automático con A y dale click izquierdo en algún lugar de la pantalla para que el robot se diriga ahí

	- R reinicia la pose del robot y la pantalla, y P pausa la simulación

	- Puedes mover la pantalla con click-derecho + drag y hacer zoom con la rueda del mouse

	- Si pulsas T, al terminar la simulación se mostrará un gráfico representando todos el torque efectuados por cada motor

